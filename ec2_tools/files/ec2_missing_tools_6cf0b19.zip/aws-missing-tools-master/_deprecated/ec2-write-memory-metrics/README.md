# Introduction:
ec2-write-memory-metrics was created to extend Amazon's default metrics for EC2 instances to include a metrics for memory usage.
# Directions For Use:
    ec2-write-memory-metrics.sh
## Example of Use:
The most valuable use of this application is to be run through cron on a regular basis.
# Additional Information:
- Author: Colin Johnson / colin@cloudavail.com
- Date: 2011-12-09
- Version 0.1
- License Type: GNU GENERAL PUBLIC LICENSE, Version 3
