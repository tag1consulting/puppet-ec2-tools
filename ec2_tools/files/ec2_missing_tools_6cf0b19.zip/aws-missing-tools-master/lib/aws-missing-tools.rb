require 'aws-missing-tools/version'

module AwsMissingTools
  require 'aws-sdk'
  require 'logger'

  require 'aws-missing-tools/aws-ha-release'
  require 'aws-missing-tools/aws-ha-release/cycle_servers'
end
